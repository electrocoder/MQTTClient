
#line 1 "MyInitTclStubs"

#if USE_TCL_STUBS
  static int
  MyInitTclStubs (Tcl_Interp *ip)
  {
    return 1;
  }
#endif
