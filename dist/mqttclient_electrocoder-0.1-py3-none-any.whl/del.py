
message = ('timestamp', '1668257775')
text = "ti"

if text in str(message):
    print("var")
else:
    print("yok")